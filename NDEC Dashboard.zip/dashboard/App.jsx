// NDEC Dashboard — React App (v2)
const { useState, useEffect, useRef, useCallback } = React;

const MAINE_PATH = `
  M 63,28 L 165,14 L 270,15
  L 289,43 L 283,79 L 265,109 L 269,144 L 287,158
  L 295,180 L 281,198 L 266,217 L 251,237
  L 236,252 L 219,268 L 203,280 L 191,294
  L 182,306 L 171,314 L 161,322 L 150,331
  L 139,341 L 127,353 L 112,367 L 98,378
  L 86,372 L 75,360 L 68,345 L 62,328
  L 55,310 L 51,292 L 51,274 L 56,257
  L 52,240 L 55,222 L 51,204 L 55,187
  L 51,170 L 55,152 L 57,134 L 54,117
  L 57,100 L 59,82 L 57,64 L 60,44 Z
`;

// ─── HELPERS ─────────────────────────────────────────────────────────────────
const fmt = (d) => d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
const fmtTime = (d) => d.toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
const timeAgo = (d) => {
  const s = Math.floor((Date.now() - d) / 1000);
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
};

const CAT_COLORS = { Safety: '#f85149', Devices: '#58a6ff', Internet: '#fbbf24', Apps: '#3fb950' };
const STATUS_COLORS = {
  'Active': '#3fb950', 'Pending Verification': '#fbbf24',
  'Approved': '#22d3ee', 'Waitlisted': '#8b949e'
};

// ─── KPI CARD ────────────────────────────────────────────────────────────────
function EnrollmentBars({ signups, mode }) {
  const { CLASSES } = window.NDEC;
  const counts = {};
  CLASSES.forEach((c) => {counts[c.id] = 0;});
  if (mode === 'enrolled') {
    signups.forEach((s) => s.classesEnrolled.forEach((c) => {counts[c.id] = (counts[c.id] || 0) + 1;}));
  } else {
    signups.forEach((s) => s.classesRecommended.forEach((c) => {counts[c.id] = (counts[c.id] || 0) + 1;}));
  }
  const rows = CLASSES.map((c) => ({ ...c, count: counts[c.id] || 0 })).sort((a, b) => b.count - a.count);
  const max = Math.max(...rows.map((r) => r.count), 1);
  return (
    <div>
      <div style={{ display: 'flex', gap: 10, marginBottom: 10, flexWrap: 'wrap' }}>
        {Object.entries(CAT_COLORS).map(([cat, col]) =>
        <div key={cat} style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 11, color: '#8b949e' }}>
            <span style={{ width: 8, height: 8, borderRadius: 2, background: col, display: 'inline-block' }} />
            {cat}
          </div>
        )}
      </div>
      {rows.map((r) => <HBar key={r.id} label={r.name} value={r.count} max={max} color={CAT_COLORS[r.category] || '#58a6ff'} />)}
    </div>);

}

function KPICard({ label, value, sub, color, live, onClick, clickable }) {
  const prev = useRef(value);
  const [flash, setFlash] = useState(false);
  useEffect(() => {if (value !== prev.current) {setFlash(true);setTimeout(() => setFlash(false), 600);}prev.current = value;}, [value]);
  return (
    <div onClick={onClick} style={{ background: flash ? '#1e2a1e' : '#161b22', border: '1px solid #30363d',
      borderTop: `3px solid ${color}`, borderRadius: 8, padding: '18px 22px',
      flex: 1, minWidth: 0, position: 'relative', transition: 'background 0.4s',
      cursor: clickable ? 'pointer' : 'default' }}
    onMouseEnter={(e) => {if (clickable) e.currentTarget.style.background = '#1c2128';}}
    onMouseLeave={(e) => {if (clickable) e.currentTarget.style.background = flash ? '#1e2a1e' : '#161b22';}}>
      {live && <span style={{ position: 'absolute', top: 12, right: 14, fontSize: 10, fontWeight: 700,
        color: '#3fb950', letterSpacing: 1, textTransform: 'uppercase', display: 'flex', alignItems: 'center', gap: 4 }}>
        <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#3fb950', display: 'inline-block', animation: 'pulse 1.4s ease infinite' }} />LIVE
      </span>}
      <div style={{ fontSize: 32, fontWeight: 700, color: '#e6edf3', lineHeight: 1, fontVariantNumeric: 'tabular-nums' }}>{value.toLocaleString()}</div>
      <div style={{ fontSize: 13, color: '#8b949e', marginTop: 6 }}>{label}</div>
      {sub && <div style={{ fontSize: 11, color: color, marginTop: 4 }}>{sub}</div>}
    </div>);

}

// ─── MAINE MAP ───────────────────────────────────────────────────────────────
function MaineMap({ signups, onNodeClick, selectedId }) {
  const [hovered, setHovered] = useState(null);
  const [tooltipPos, setTooltipPos] = useState({ x: 0, y: 0 });
  const svgRef = useRef();

  const clusters = {};
  signups.forEach((s) => {
    const key = `${Math.round(s.mapX / 6) * 6},${Math.round(s.mapY / 6) * 6}`;
    if (!clusters[key]) clusters[key] = [];
    clusters[key].push(s);
  });
  const nodes = Object.entries(clusters).map(([key, members]) => ({
    key, members,
    x: members.reduce((a, b) => a + b.mapX, 0) / members.length,
    y: members.reduce((a, b) => a + b.mapY, 0) / members.length,
    pctInternet: members.filter((m) => m.onboarding.q2_internet_home).length / members.length,
    r: Math.max(5, Math.min(14, 4 + members.length * 0.8)),
    isSelected: members.some((m) => m.id === selectedId)
  }));

  return (
    <div style={{ position: 'relative', width: '100%', height: '100%' }}>
      <svg ref={svgRef} viewBox="0 0 360 420" style={{ width: '100%', height: '100%', display: 'block' }} preserveAspectRatio="xMidYMid meet">
        <defs>
          <filter id="glow"><feGaussianBlur stdDeviation="2.5" result="cb" /><feMerge><feMergeNode in="cb" /><feMergeNode in="SourceGraphic" /></feMerge></filter>
          <filter id="glows"><feGaussianBlur stdDeviation="4" result="cb" /><feMerge><feMergeNode in="cb" /><feMergeNode in="SourceGraphic" /></feMerge></filter>
        </defs>
        <rect width="360" height="420" fill="#0d1117" />
        <path d={MAINE_PATH} fill="#1a2030" stroke="#30363d" strokeWidth="1.5" />
        {[{ label: 'Portland', x: 132, y: 348 }, { label: 'Bangor', x: 198, y: 178 }, { label: 'Augusta', x: 155, y: 258 }, { label: 'Presque Isle', x: 245, y: 48 }, { label: 'Ellsworth', x: 226, y: 224 }].map((c) =>
        <text key={c.label} x={c.x} y={c.y} fontSize="7" fill="#4b5563" textAnchor="middle" fontFamily="'Helvetica Neue',sans-serif" letterSpacing="0.5">{c.label}</text>
        )}
        <text x="118" y="200" fontSize="22" fill="#ffffff" fillOpacity="0.04" fontFamily="'Helvetica Neue',sans-serif" fontWeight="700" letterSpacing="8">MAINE</text>
        {nodes.map((node) => {
          const col = node.pctInternet > 0.5 ? '#58a6ff' : '#f59e0b';
          return (
            <g key={node.key} style={{ cursor: 'pointer' }}
            onClick={() => onNodeClick(node.members[0])}
            onMouseEnter={(e) => {
              setHovered(node);
              const r = svgRef.current.getBoundingClientRect();
              setTooltipPos({ x: node.x * (r.width / 360) + r.left, y: node.y * (r.height / 420) + r.top });
            }}
            onMouseLeave={() => setHovered(null)}>
              {node.members.some((m) => m.isNew) && <circle cx={node.x} cy={node.y} r={node.r + 6} fill="none" stroke="#3fb950" strokeWidth="1.5" style={{ animation: 'ripple 1.5s ease-out infinite' }} opacity="0.7" />}
              {node.isSelected && <circle cx={node.x} cy={node.y} r={node.r + 4} fill="none" stroke="#ffffff" strokeWidth="1.5" opacity="0.8" />}
              <circle cx={node.x} cy={node.y} r={node.r + 2} fill={col} opacity="0.18" filter="url(#glow)" />
              <circle cx={node.x} cy={node.y} r={node.r} fill={col} opacity={node.isSelected ? 1 : 0.85} filter={node.isSelected ? 'url(#glows)' : undefined} />
              {node.members.length > 1 && <text x={node.x} y={node.y + 3.5} textAnchor="middle" fontSize={node.r > 9 ? 7 : 6} fontWeight="700" fill="#0d1117" fontFamily="'Helvetica Neue',sans-serif">{node.members.length}</text>}
            </g>);

        })}
        <text x="295" y="310" fontSize="7.5" fill="#ffffff" fillOpacity="0.18" fontFamily="'Helvetica Neue',sans-serif" fontStyle="italic" transform="rotate(-35,295,310)">Atlantic Ocean</text>
      </svg>
      {hovered &&
      <div style={{ position: 'fixed', left: tooltipPos.x + 12, top: tooltipPos.y - 10, background: '#1c2128', border: '1px solid #30363d', borderRadius: 6, padding: '8px 12px', fontSize: 12, color: '#e6edf3', pointerEvents: 'none', zIndex: 100, whiteSpace: 'nowrap', boxShadow: '0 4px 16px #00000060' }}>
          <div style={{ fontWeight: 700 }}>{hovered.members[0].town}, {hovered.members[0].county} Co.</div>
          <div style={{ color: '#8b949e', marginTop: 2 }}>{hovered.members.length} enrollment{hovered.members.length > 1 ? 's' : ''}</div>
          <div style={{ color: hovered.pctInternet > 0.5 ? '#58a6ff' : '#f59e0b', marginTop: 2, fontSize: 11 }}>{Math.round(hovered.pctInternet * 100)}% have home internet</div>
        </div>
      }
      <div style={{ position: 'absolute', bottom: 10, left: 10, background: '#0d111799', backdropFilter: 'blur(4px)', border: '1px solid #30363d', borderRadius: 6, padding: '8px 12px', fontSize: 11, color: '#8b949e', display: 'flex', flexDirection: 'column', gap: 5 }}>
        {[['#58a6ff', 'Has home internet'], ['#f59e0b', 'No home internet'], ['border:#3fb950', 'New signup']].map(([c, l]) =>
        <div key={l} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ width: 9, height: 9, borderRadius: '50%', background: c.startsWith('border') ? 'transparent' : '', border: c.startsWith('border') ? `1.5px solid #3fb950` : 'none', background: c.startsWith('border') ? 'transparent' : c, display: 'inline-block' }} />
            {l}
          </div>
        )}
      </div>
    </div>);

}

// ─── DETAIL PANEL ────────────────────────────────────────────────────────────
function Section({ title, children }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <div style={{ fontSize: 10, fontWeight: 700, color: '#484f58', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 8, paddingBottom: 5, borderBottom: '1px solid #21262d' }}>{title}</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>{children}</div>
    </div>);

}
function Row({ label, value, valueColor, mono }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8 }}>
      <span style={{ fontSize: 11, color: '#8b949e', flexShrink: 0 }}>{label}</span>
      <span style={{ fontSize: 12, color: valueColor || '#c9d1d9', textAlign: 'right', fontFamily: mono ? 'monospace' : 'inherit' }}>{value}</span>
    </div>);

}

function DetailPanel({ signup, onClose }) {
  if (!signup) return null;
  const { pg, sp } = { pg: signup.partnerGroup, sp: signup.sponsorship };
  const ob = signup.onboarding;
  return (
    <div style={{ position: 'absolute', top: 0, right: 0, bottom: 0, width: 310, background: '#161b22', borderLeft: '1px solid #30363d', overflowY: 'auto', zIndex: 50, display: 'flex', flexDirection: 'column' }}>
      {/* Header */}
      <div style={{ padding: '14px 16px', borderBottom: '1px solid #30363d', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexShrink: 0 }}>
        <div>
          <div style={{ fontSize: 15, fontWeight: 700, color: '#e6edf3' }}>{signup.display_name}</div>
          <div style={{ fontSize: 11, color: '#8b949e', marginTop: 2, fontFamily: 'monospace' }}>{signup.user_login}</div>
          <div style={{ fontSize: 11, color: '#58a6ff', marginTop: 1 }}>{signup.user_email}</div>
        </div>
        <button onClick={onClose} style={{ background: 'none', border: 'none', color: '#8b949e', cursor: 'pointer', fontSize: 18, padding: 0, lineHeight: 1 }}>✕</button>
      </div>

      <div style={{ padding: '14px 16px', flex: 1, overflowY: 'auto' }}>
        {/* Status */}
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 14 }}>
          <Badge color={signup.isActive ? '#3fb950' : '#f85149'} bg={signup.isActive ? '#1a2f1a' : '#2a1a1a'}>{signup.isActive ? '● Active' : '○ Inactive'}</Badge>
          {signup.isNew && <Badge color="#3fb950" bg="#1a2a1a">✦ New</Badge>}
          {sp && <Badge color={STATUS_COLORS[sp.status] || '#8b949e'} bg="#1c2128">{sp.status}</Badge>}
        </div>

        <Section title="Account">
          <Row label="User Login" value={signup.user_login} mono />
          <Row label="Email" value={signup.user_email} valueColor="#58a6ff" />
          <Row label="Display Name" value={signup.display_name} />
          <Row label="Registered" value={fmt(signup.user_registered)} />
          <Row label="Last Login" value={fmtTime(signup.last_login)} />
        </Section>

        <Section title="Location">
          <Row label="Town / City" value={signup.town} />
          <Row label="County" value={`${signup.county} County`} />
          <Row label="State" value={signup.state} />
          <Row label="ZIP Code" value={signup.zip} mono />
        </Section>

        <Section title="Onboarding Answers">
          <Row label="ZIP Checked" value={ob.q1_zip} mono />
          <Row label="Partner Eligible" value={ob.q1_partner_check ? 'Yes' : 'No'} valueColor={ob.q1_partner_check ? '#22d3ee' : '#8b949e'} />
          <Row label="Internet at Home" value={ob.q2_internet_home ? '✓ Yes' : '✗ No'} valueColor={ob.q2_internet_home ? '#3fb950' : '#f59e0b'} />
          {ob.q3_affordable_interest && <Row label="Affordable Interest" value={ob.q3_affordable_interest} />}
          <Row label="Main Goal" value={ob.main_goal} />
          <Row label="Device" value={ob.device_type} />
          <Row label="Experience" value={ob.experience_level} />
          {ob.household_size && <Row label="Household Size" value={ob.household_size} />}
        </Section>

        <Section title="Classes Recommended">
          {signup.classesRecommended.map((c) =>
          <div key={c.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '4px 8px', background: '#1c2128', borderRadius: 4 }}>
              <span style={{ fontSize: 12, color: '#c9d1d9' }}>{c.name}</span>
              <span style={{ fontSize: 10, color: CAT_COLORS[c.category] || '#8b949e', flexShrink: 0, marginLeft: 6 }}>{c.category}</span>
            </div>
          )}
        </Section>

        <Section title="Classes Enrolled">
          {signup.classesEnrolled.length === 0 ?
          <div style={{ fontSize: 12, color: '#484f58' }}>No enrollments yet</div> :
          signup.classesEnrolled.map((c, i) =>
          <div key={i} style={{ padding: '6px 8px', background: '#1c2128', borderRadius: 4, border: `1px solid ${c.completed ? '#3fb95030' : '#21262d'}` }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontSize: 12, color: '#e6edf3', fontWeight: 500 }}>{c.name}</span>
                  {c.completed && <span style={{ fontSize: 10, color: '#3fb950' }}>✓ Done</span>}
                </div>
                <div style={{ fontSize: 11, color: '#8b949e', marginTop: 3, display: 'flex', gap: 10 }}>
                  <span>{fmt(c.enrolledDate)}</span>
                  <span style={{ color: CAT_COLORS[c.category] }}>{c.format}</span>
                </div>
              </div>
          )
          }
        </Section>

        {sp &&
        <Section title="Sponsorship">
            <Row label="Program" value={sp.programName} />
            <Row label="Sponsor Code" value={sp.sponsorCode} mono />
            <Row label="Status" value={sp.status} valueColor={STATUS_COLORS[sp.status]} />
            <Row label="Free Classes" value={sp.eligibleFree ? 'Yes' : 'No'} valueColor={sp.eligibleFree ? '#3fb950' : '#8b949e'} />
            <Row label="Household Size" value={sp.householdSize} />
            {sp.verifiedDate && <Row label="Verified" value={fmt(sp.verifiedDate)} />}
            {sp.notes && <Row label="Notes" value={sp.notes} valueColor="#fbbf24" />}
          </Section>
        }
      </div>
    </div>);

}

function Badge({ color, bg, children }) {
  return (
    <span style={{ padding: '3px 10px', borderRadius: 12, fontSize: 11, fontWeight: 600, background: bg, color, border: `1px solid ${color}40` }}>{children}</span>);

}

// ─── HBAR CHART ──────────────────────────────────────────────────────────────
function HBar({ label, value, max, color }) {
  const pct = max > 0 ? value / max * 100 : 0;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 7 }}>
      <div style={{ width: 160, fontSize: 11, color: '#8b949e', textAlign: 'right', flexShrink: 0, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{label}</div>
      <div style={{ flex: 1, height: 13, background: '#21262d', borderRadius: 3, overflow: 'hidden' }}>
        <div style={{ width: `${pct}%`, height: '100%', background: color, borderRadius: 3, transition: 'width 0.6s ease' }} />
      </div>
      <div style={{ width: 28, fontSize: 11, color: '#e6edf3', fontVariantNumeric: 'tabular-nums', textAlign: 'right', flexShrink: 0 }}>{value}</div>
    </div>);

}

// ─── PARTNER CARD ─────────────────────────────────────────────────────────────
function PartnerCard({ pg, count, pct }) {
  return (
    <div style={{ background: '#1c2128', border: '1px solid #21262d', borderLeft: `3px solid ${pg.color}`, borderRadius: 6, padding: '13px 15px', display: 'flex', flexDirection: 'column', gap: 7 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: '#e6edf3', lineHeight: 1.3, paddingRight: 8 }}>{pg.name}</div>
        <div style={{ fontSize: 22, fontWeight: 700, color: pg.color, flexShrink: 0 }}>{count}</div>
      </div>
      <div style={{ height: 4, background: '#30363d', borderRadius: 2 }}>
        <div style={{ width: `${pct}%`, height: '100%', background: pg.color, borderRadius: 2, transition: 'width 0.6s' }} />
      </div>
      <div style={{ fontSize: 11, color: '#8b949e' }}>{pct.toFixed(1)}% of partner enrollments</div>
    </div>);

}

// ─── ENROLLMENT PANEL ────────────────────────────────────────────────────────
function EnrollmentPanel({ signups }) {
  const [tab, setTab] = useState('classes');
  const { PARTNER_GROUPS, CLASSES } = window.NDEC;
  const classCounts = {};
  CLASSES.forEach((c) => {classCounts[c.id] = 0;});
  signups.forEach((s) => s.classesEnrolled.forEach((c) => {classCounts[c.id] = (classCounts[c.id] || 0) + 1;}));
  const recCounts = {};
  CLASSES.forEach((c) => {recCounts[c.id] = 0;});
  signups.forEach((s) => s.classesRecommended.forEach((c) => {recCounts[c.id] = (recCounts[c.id] || 0) + 1;}));
  const classRows = CLASSES.map((c) => ({ ...c, enrolled: classCounts[c.id] || 0, recommended: recCounts[c.id] || 0 })).sort((a, b) => b.enrolled - a.enrolled);
  const maxE = Math.max(...classRows.map((r) => r.enrolled), 1);
  const maxR = Math.max(...classRows.map((r) => r.recommended), 1);
  const pgCounts = {};
  signups.forEach((s) => {if (s.partnerGroup) pgCounts[s.partnerGroup.id] = (pgCounts[s.partnerGroup.id] || 0) + 1;});
  const totalPG = Object.values(pgCounts).reduce((a, b) => a + b, 0) || 1;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
      <div style={{ display: 'flex', borderBottom: '1px solid #30363d', flexShrink: 0 }}>
        {[['classes', 'Enrolled by Class'], ['recommended', 'Recommended'], ['partners', 'Partner Groups']].map(([id, label]) =>
        <button key={id} onClick={() => setTab(id)} style={{ padding: '10px 14px', fontSize: 12, fontWeight: tab === id ? 600 : 400, color: tab === id ? '#e6edf3' : '#8b949e', background: 'none', border: 'none', borderBottom: tab === id ? '2px solid #58a6ff' : '2px solid transparent', cursor: 'pointer', transition: 'all 0.2s', marginBottom: -1, whiteSpace: 'nowrap' }}>{label}</button>
        )}
      </div>

      {(tab === 'classes' || tab === 'recommended') &&
      <div style={{ flex: 1, overflowY: 'auto', padding: '14px 16px' }}>
          <div style={{ display: 'flex', gap: 12, marginBottom: 12, flexWrap: 'wrap' }}>
            {Object.entries(CAT_COLORS).map(([cat, col]) =>
          <div key={cat} style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 11, color: '#8b949e' }}>
                <span style={{ width: 8, height: 8, borderRadius: 2, background: col, display: 'inline-block' }} />
                {cat}
              </div>
          )}
          </div>
          {classRows.map((r) =>
        <HBar key={r.id} label={r.name} value={tab === 'classes' ? r.enrolled : r.recommended} max={tab === 'classes' ? maxE : maxR} color={CAT_COLORS[r.category] || '#58a6ff'} />
        )}
        </div>
      }

      {tab === 'partners' &&
      <div style={{ flex: 1, overflowY: 'auto', padding: '14px 16px', display: 'flex', flexDirection: 'column', gap: 9 }}>
          {PARTNER_GROUPS.map((pg) => {
          const count = pgCounts[pg.id] || 0;
          return <PartnerCard key={pg.id} pg={pg} count={count} pct={count / totalPG * 100} />;
        })}
          <div style={{ padding: '10px 0', fontSize: 12, color: '#8b949e', textAlign: 'center', borderTop: '1px solid #21262d', marginTop: 4 }}>
            {signups.filter((s) => !s.partnerGroup).length} enrollments outside partner groups
          </div>
        </div>
      }
    </div>);

}

// ─── LIVE FEED ───────────────────────────────────────────────────────────────
function LiveFeed({ recentSignups }) {
  const [expanded, setExpanded] = useState(null);
  return (
    <div style={{ background: '#161b22', border: '1px solid #30363d', borderRadius: 8, overflow: 'hidden', height: '100%', display: 'flex', flexDirection: 'column' }}>
      <div style={{ padding: '10px 16px', borderBottom: '1px solid #30363d', fontSize: 12, fontWeight: 700, color: '#8b949e', textTransform: 'uppercase', letterSpacing: 1, display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0 }}>
        <span style={{ width: 7, height: 7, borderRadius: '50%', background: '#3fb950', display: 'inline-block', animation: 'pulse 1.4s ease infinite' }} />
        Live Enrollment Feed
        <span style={{ marginLeft: 'auto', fontWeight: 400, fontSize: 11, textTransform: 'none', letterSpacing: 0, color: "rgb(139, 148, 158)" }}>{recentSignups.length} recent · click to expand</span>
        <button onClick={()=>exportCSV(recentSignups)} style={{padding:'4px 12px',fontSize:11,fontWeight:600,background:'#21262d',border:'1px solid #30363d',borderRadius:5,color:'#e6edf3',cursor:'pointer',textTransform:'none',letterSpacing:0,transition:'background 0.15s'}}
          onMouseEnter={e=>e.currentTarget.style.background='#30363d'}
          onMouseLeave={e=>e.currentTarget.style.background='#21262d'}>
          ↓ Export CSV
        </button>
      </div>
      <div style={{ overflowY: 'auto', flex: 1, display: 'flex', flexDirection: 'column' }}>
        {recentSignups.map((s) =>
        <div key={s.id} style={{ borderBottom: '1px solid #21262d' }}>
            <div onClick={() => setExpanded(expanded === s.id ? null : s.id)}
          style={{ padding: '10px 14px', cursor: 'pointer', background: s.isNew ? '#1a2f1a' : expanded === s.id ? '#1c2128' : 'transparent', transition: 'background 0.2s', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 6 }}>
              <div style={{ minWidth: 0, flex: 1 }}>
                <div style={{ fontSize: 13, color: '#e6edf3', fontWeight: 600, display: 'flex', alignItems: 'center', gap: 5 }}>
                  {s.isNew && <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#3fb950', display: 'inline-block', flexShrink: 0 }} />}
                  {s.display_name}
                  {s.partnerGroup && <span style={{ width: 7, height: 7, borderRadius: '50%', background: s.partnerGroup.color, display: 'inline-block', flexShrink: 0, marginLeft: 2 }} />}
                </div>
                <div style={{ fontSize: 11, color: '#8b949e', marginTop: 2, display: 'flex', gap: 10 }}>
                  <span style={{ fontFamily: 'monospace' }}>{s.user_login}</span>
                  <span>·</span>
                  <span>{s.town}, {s.state}</span>
                  <span>·</span>
                  <span style={{ color: s.onboarding.q2_internet_home ? '#3fb950' : '#f59e0b' }}>{s.onboarding.q2_internet_home ? '✓ Internet' : '✗ No internet'}</span>
                </div>
                <div style={{ fontSize: 11, color: '#484f58', marginTop: 2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{s.onboarding.main_goal}</div>
              </div>
              <div style={{ fontSize: 10, color: '#484f58', flexShrink: 0, marginTop: 1, textAlign: 'right' }}>
                <div>{timeAgo(s.user_registered)}</div>
                {s.classesEnrolled[0] && <div style={{ color: '#8b949e', marginTop: 2 }}>{s.classesEnrolled.length} class{s.classesEnrolled.length!==1?'es':''} enrolled</div>}
              </div>
            </div>
            {expanded === s.id &&
          <div style={{ padding: '10px 14px', background: '#13181f', borderTop: '1px solid #21262d', fontSize: 11 }}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 24px' }}>
                  <div>
                    <FeedRow label="Login" value={s.user_login} mono />
                    <FeedRow label="Email" value={s.user_email} color="#58a6ff" />
                    <FeedRow label="Registered" value={fmt(s.user_registered)} />
                    <FeedRow label="Last Login" value={fmtTime(s.last_login)} />
                    <div style={{ height: 1, background: '#21262d', margin: '7px 0' }} />
                    <FeedRow label="Town" value={`${s.town}, ${s.state}`} />
                    <FeedRow label="County" value={`${s.county} County`} />
                    <FeedRow label="ZIP" value={s.zip} mono />
                  </div>
                  <div>
                    <FeedRow label="Internet at Home" value={s.onboarding.q2_internet_home ? '✓ Yes' : '✗ No'} color={s.onboarding.q2_internet_home ? '#3fb950' : '#f59e0b'} />
                    <FeedRow label="Goal" value={s.onboarding.main_goal} />
                    <FeedRow label="Device" value={s.onboarding.device_type} />
                    <FeedRow label="Experience" value={s.onboarding.experience_level} />
                    {s.onboarding.household_size && <FeedRow label="Household" value={s.onboarding.household_size} />}
                    {s.onboarding.q3_affordable_interest && <FeedRow label="Affordable?" value="Interested" color="#fbbf24" />}
                  </div>
                </div>
                <div style={{ height: 1, background: '#21262d', margin: '8px 0' }} />
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 24px' }}>
                  <div>
                    <div style={{ color: '#484f58', fontSize: 10, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 4 }}>Recommended</div>
                    {s.classesRecommended.map((c) => <div key={c.id} style={{ color: '#8b949e', paddingLeft: 8, marginBottom: 2 }}>· {c.name}</div>)}
                  </div>
                  <div>
                    <div style={{ color: '#484f58', fontSize: 10, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 4 }}>Enrolled</div>
                    {s.classesEnrolled.length === 0 ?
                <div style={{ color: '#484f58', paddingLeft: 8 }}>None yet</div> :
                s.classesEnrolled.map((c, i) =>
                <div key={i} style={{ paddingLeft: 8, marginBottom: 3 }}>
                          <span style={{ color: '#c9d1d9' }}>· {c.name}</span>
                          <span style={{ color: '#484f58', marginLeft: 6 }}>{fmt(c.enrolledDate)}</span>
                          <span style={{ color: CAT_COLORS[c.category], marginLeft: 5 }}>{c.format}</span>
                          {c.completed && <span style={{ color: '#3fb950', marginLeft: 4 }}>✓</span>}
                        </div>
                )
                }
                  </div>
                </div>
                {s.sponsorship && <>
                  <div style={{ height: 1, background: '#21262d', margin: '8px 0' }} />
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 24px' }}>
                    <div>
                      <div style={{ color: '#484f58', fontSize: 10, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 4 }}>Sponsorship</div>
                      <FeedRow label="Program" value={s.sponsorship.programName} />
                      <FeedRow label="Code" value={s.sponsorship.sponsorCode} mono />
                    </div>
                    <div style={{ paddingTop: 16 }}>
                      <FeedRow label="Status" value={s.sponsorship.status} color={STATUS_COLORS[s.sponsorship.status]} />
                      <FeedRow label="Free" value={s.sponsorship.eligibleFree ? 'Yes' : 'No'} color={s.sponsorship.eligibleFree ? '#3fb950' : '#8b949e'} />
                      {s.sponsorship.notes && <FeedRow label="Notes" value={s.sponsorship.notes} color="#fbbf24" />}
                    </div>
                  </div>
                </>}
              </div>
          }
          </div>
        )}
      </div>
    </div>);

}

function FeedRow({ label, value, color, mono }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8, marginBottom: 3 }}>
      <span style={{ color: '#484f58', flexShrink: 0 }}>{label}</span>
      <span style={{ color: color || '#8b949e', textAlign: 'right', fontFamily: mono ? 'monospace' : 'inherit', wordBreak: 'break-all' }}>{value}</span>
    </div>);

}

// ─── SIGNUP TABLE ────────────────────────────────────────────────────────────
function exportCSV(signups) {
  const rows = [
  ['ID', 'Display Name', 'User Login', 'Email', 'First Name', 'Last Name', 'Town', 'County', 'State', 'ZIP',
  'Registered', 'Last Login', 'Active',
  'Internet at Home', 'Affordable Interest', 'Goal', 'Device', 'Experience', 'Household Size',
  'Classes Recommended', 'Classes Enrolled', 'Enrollment Dates', 'Completed',
  'Partner Group', 'Sponsor Code', 'Sponsor Status', 'Free Classes', 'Sponsor Household', 'Verified Date', 'Notes']];

  signups.forEach((s) => {
    const ob = s.onboarding;
    const sp = s.sponsorship;
    rows.push([
    s.id, s.display_name, s.user_login, s.user_email, s.first_name, s.last_name,
    s.town, s.county, s.state, s.zip,
    s.user_registered.toISOString(), s.last_login.toISOString(), s.isActive ? 'Yes' : 'No',
    ob.q2_internet_home ? 'Yes' : 'No',
    ob.q3_affordable_interest || '',
    ob.main_goal, ob.device_type, ob.experience_level, ob.household_size || '',
    s.classesRecommended.map((c) => c.name).join('; '),
    s.classesEnrolled.map((c) => c.name).join('; '),
    s.classesEnrolled.map((c) => c.enrolledDate.toISOString().slice(0, 10)).join('; '),
    s.classesEnrolled.filter((c) => c.completed).length + '/' + s.classesEnrolled.length,
    sp?.programName || '', sp?.sponsorCode || '', sp?.status || '', sp?.eligibleFree ? 'Yes' : 'No',
    sp?.householdSize || '', sp?.verifiedDate ? sp.verifiedDate.toISOString().slice(0, 10) : '',
    sp?.notes || '']
    );
  });
  const csv = rows.map((r) => r.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `NDEC_Enrollments_${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

function SignupTable({ signups }) {
  const [search, setSearch] = useState('');
  const [sortKey, setSortKey] = useState('user_registered');
  const [sortDir, setSortDir] = useState('desc');
  const [page, setPage] = useState(0);
  const [cols, setCols] = useState('standard'); // 'standard' | 'onboarding' | 'classes' | 'sponsorship'
  const PAGE = 12;

  const filtered = signups.filter((s) => {
    const q = search.toLowerCase();
    return !q || `${s.display_name} ${s.user_login} ${s.user_email} ${s.town} ${s.zip} ${s.county}`.toLowerCase().includes(q);
  });

  const sorted = [...filtered].sort((a, b) => {
    let av = a[sortKey] ?? '',bv = b[sortKey] ?? '';
    if (av instanceof Date) {av = av.getTime();bv = bv.getTime();}
    if (typeof av === 'string') return sortDir === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av);
    return sortDir === 'asc' ? av - bv : bv - av;
  });
  const paged = sorted.slice(page * PAGE, (page + 1) * PAGE);
  const totalPages = Math.ceil(sorted.length / PAGE);
  const toggleSort = (key) => {if (sortKey === key) setSortDir((d) => d === 'asc' ? 'desc' : 'asc');else {setSortKey(key);setSortDir('asc');}};

  const th = { padding: '10px 16px', fontSize: 11, color: '#8b949e', textAlign: 'left', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5, borderBottom: '1px solid #30363d', cursor: 'pointer', userSelect: 'none', whiteSpace: 'nowrap' };
  const td = { padding: '10px 16px', fontSize: 12, color: '#c9d1d9', borderBottom: '1px solid #21262d', verticalAlign: 'top' };
  const S = (key) => sortKey === key ? sortDir === 'asc' ? ' ↑' : ' ↓' : '';

  const VIEW_COLS = {
    standard: [
    { key: 'display_name', label: 'Name' },
    { key: 'user_login', label: 'Username' },
    { key: 'user_email', label: 'Email' },
    { key: 'town', label: 'Town' },
    { key: 'county', label: 'County' },
    { key: 'state', label: 'State' },
    { key: 'zip', label: 'ZIP' },
    { key: 'user_registered', label: 'Registered' },
    { key: 'last_login', label: 'Last Login' },
    { key: null, label: 'Status' }],

    onboarding: [
    { key: 'display_name', label: 'Name' },
    { key: 'town', label: 'Town' },
    { key: null, label: 'Internet' },
    { key: null, label: 'Affordable?' },
    { key: null, label: 'Goal' },
    { key: null, label: 'Device' },
    { key: null, label: 'Experience' },
    { key: null, label: 'Household' }],

    classes: [
    { key: 'display_name', label: 'Name' },
    { key: 'town', label: 'Town' },
    { key: null, label: 'Recommended' },
    { key: null, label: 'Enrolled' },
    { key: null, label: 'Enroll Dates' },
    { key: null, label: 'Format' },
    { key: null, label: 'Completed' }],

    sponsorship: [
    { key: 'display_name', label: 'Name' },
    { key: 'town', label: 'Town' },
    { key: null, label: 'Partner Group' },
    { key: null, label: 'Sponsor Code' },
    { key: null, label: 'Status' },
    { key: null, label: 'Free Classes' },
    { key: null, label: 'Household' },
    { key: null, label: 'Verified' },
    { key: null, label: 'Notes' }]

  };

  function renderCell(s, col) {
    const ob = s.onboarding;
    const sp = s.sponsorship;
    switch (col.label) {
      case 'Name':return <span style={{ fontWeight: 500, color: '#e6edf3', display: 'flex', alignItems: 'center', gap: 5 }}>{s.isNew && <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#3fb950', display: 'inline-block', flexShrink: 0 }} />}{s.display_name}</span>;
      case 'Username':return <span style={{ fontFamily: 'monospace', fontSize: 11 }}>{s.user_login}</span>;
      case 'Email':return <span style={{ color: '#58a6ff', fontSize: 11 }}>{s.user_email}</span>;
      case 'Town':return s.town;
      case 'County':return s.county;
      case 'State':return s.state;
      case 'ZIP':return <span style={{ fontFamily: 'monospace' }}>{s.zip}</span>;
      case 'Registered':return <span style={{ fontSize: 11 }}>{fmt(s.user_registered)}</span>;
      case 'Last Login':return <span style={{ fontSize: 11 }}>{fmtTime(s.last_login)}</span>;
      case 'Status':return <span style={{ fontSize: 11, fontWeight: 600, color: s.isActive ? '#3fb950' : '#f85149' }}>{s.isActive ? 'Active' : 'Inactive'}</span>;
      case 'Internet':return <span style={{ fontSize: 11, fontWeight: 600, color: ob.q2_internet_home ? '#3fb950' : '#f59e0b' }}>{ob.q2_internet_home ? '✓ Yes' : '✗ No'}</span>;
      case 'Affordable?':return <span style={{ fontSize: 11, color: '#8b949e' }}>{ob.q3_affordable_interest ? 'Yes' : '—'}</span>;
      case 'Goal':return <span style={{ fontSize: 11, color: '#8b949e' }}>{ob.main_goal}</span>;
      case 'Device':return <span style={{ fontSize: 11 }}>{ob.device_type}</span>;
      case 'Experience':return <span style={{ fontSize: 11, color: '#8b949e' }}>{ob.experience_level}</span>;
      case 'Household':return <span>{ob.household_size || sp?.householdSize || '—'}</span>;
      case 'Recommended':return <div style={{ display: 'flex', gap: 3, flexWrap: 'wrap' }}>{s.classesRecommended.map((c) => <Chip key={c.id} color={CAT_COLORS[c.category]}>{c.name}</Chip>)}</div>;
      case 'Enrolled':return <div style={{ display: 'flex', gap: 3, flexWrap: 'wrap' }}>{s.classesEnrolled.length===0 ? <span style={{fontSize:11,color:'#484f58'}}>None yet</span> : s.classesEnrolled.map((c, i) => <Chip key={i} color={CAT_COLORS[c.category]}>{c.name}{c.completed?' ✓':''}</Chip>)}</div>;
      case 'Enroll Dates':return <span style={{ fontSize: 11, color: '#8b949e' }}>{s.classesEnrolled[0] ? fmt(s.classesEnrolled[0].enrolledDate) : '—'}</span>;
      case 'Format':return <span style={{ fontSize: 11, color: '#22d3ee' }}>{s.classesEnrolled[0]?.format || '—'}</span>;
      case 'Completed':return <span style={{ fontSize: 11, color: s.classesEnrolled.some((c) => c.completed) ? '#3fb950' : '#484f58' }}>{s.classesEnrolled.filter((c) => c.completed).length}/{s.classesEnrolled.length}</span>;
      case 'Partner Group':return sp ? <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}><span style={{ width: 7, height: 7, borderRadius: '50%', background: s.partnerGroup.color, display: 'inline-block', flexShrink: 0 }} /><span style={{ fontSize: 11 }}>{s.partnerGroup.abbr}</span></span> : <span style={{ color: '#484f58', fontSize: 11 }}>—</span>;
      case 'Sponsor Code':return sp ? <span style={{ fontFamily: 'monospace', fontSize: 11 }}>{sp.sponsorCode}</span> : <span style={{ color: '#484f58' }}>—</span>;
      case 'Status':return sp ? <span style={{ fontSize: 11, fontWeight: 600, color: STATUS_COLORS[sp.status] || '#8b949e' }}>{sp.status}</span> : <span style={{ color: '#484f58' }}>—</span>;
      case 'Free Classes':return sp ? <span style={{ fontSize: 11, color: sp.eligibleFree ? '#3fb950' : '#8b949e' }}>{sp.eligibleFree ? 'Yes' : 'No'}</span> : <span style={{ color: '#484f58' }}>—</span>;
      case 'Verified':return sp?.verifiedDate ? <span style={{ fontSize: 11 }}>{fmt(sp.verifiedDate)}</span> : <span style={{ fontSize: 11, color: '#484f58' }}>Pending</span>;
      case 'Notes':return sp?.notes ? <span style={{ fontSize: 11, color: '#fbbf24' }}>{sp.notes}</span> : <span style={{ color: '#484f58' }}>—</span>;
      default:return '—';
    }
  }

  const activeCols = VIEW_COLS[cols];

  return (
    <div style={{ background: '#161b22', border: '1px solid #30363d', borderRadius: 8, overflow: 'hidden', marginTop: 16 }}>
      <div style={{ padding: '12px 16px', borderBottom: '1px solid #30363d', display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
        <div style={{ fontSize: 14, fontWeight: 600, color: '#e6edf3', display: 'flex', alignItems: 'center', gap: 10 }}>
          Enrollment Records
          <span style={{ fontSize: 12, fontWeight: 400, color: '#8b949e' }}>{filtered.length} results</span>
        </div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          {/* View selector */}
          <div style={{ display: 'flex', background: '#0d1117', border: '1px solid #30363d', borderRadius: 6, overflow: 'hidden' }}>
            {[['standard', 'Overview'], ['onboarding', 'Onboarding'], ['classes', 'Classes'], ['sponsorship', 'Sponsorship']].map(([id, lbl]) =>
            <button key={id} onClick={() => {setCols(id);setPage(0);}} style={{ padding: '5px 11px', fontSize: 11, background: cols === id ? '#21262d' : 'transparent', color: cols === id ? '#e6edf3' : '#8b949e', border: 'none', cursor: 'pointer', borderRight: '1px solid #30363d', fontWeight: cols === id ? 600 : 400 }}>{lbl}</button>
            )}
          </div>
          <button onClick={() => exportCSV(filtered)} style={{
            padding: '5px 13px', fontSize: 12, fontWeight: 600,
            background: '#21262d', border: '1px solid #30363d', borderRadius: 6,
            color: '#e6edf3', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6,
            transition: 'background 0.15s'
          }}
          onMouseEnter={(e) => e.currentTarget.style.background = '#30363d'}
          onMouseLeave={(e) => e.currentTarget.style.background = '#21262d'}>
            ↓ Export CSV
          </button>
          <input value={search} onChange={(e) => {setSearch(e.target.value);setPage(0);}} placeholder="Search…"
          style={{ background: '#0d1117', border: '1px solid #30363d', borderRadius: 6, color: '#e6edf3', fontSize: 12, padding: '5px 11px', width: 180, outline: 'none' }} />
        </div>
      </div>

      <div style={{ overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr>
              {activeCols.map((col) =>
              <th key={col.label} style={th} onClick={col.key ? () => toggleSort(col.key) : undefined}>
                  {col.label}{col.key ? S(col.key) : ''}
                </th>
              )}
            </tr>
          </thead>
          <tbody>
            {paged.map((s) =>
            <tr key={s.id}
            onMouseEnter={(e) => e.currentTarget.style.background = '#1c2128'}
            onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}>
                {activeCols.map((col) =>
              <td key={col.label} style={td}>{renderCell(s, col)}</td>
              )}
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div style={{ padding: '11px 16px', borderTop: '1px solid #30363d', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ fontSize: 12, color: '#8b949e' }}>Showing {page * PAGE + 1}–{Math.min((page + 1) * PAGE, sorted.length)} of {sorted.length}</div>
        <div style={{ display: 'flex', gap: 5 }}>
          {Array.from({ length: totalPages }, (_, i) => i).slice(Math.max(0, page - 2), page + 5).map((i) =>
          <button key={i} onClick={() => setPage(i)} style={{ width: 28, height: 28, borderRadius: 4, fontSize: 12, background: i === page ? '#58a6ff22' : 'none', border: i === page ? '1px solid #58a6ff' : '1px solid #30363d', color: i === page ? '#58a6ff' : '#8b949e', cursor: 'pointer' }}>{i + 1}</button>
          )}
        </div>
      </div>
    </div>);

}

function Chip({ color, children }) {
  return <span style={{ fontSize: 10, padding: '2px 6px', borderRadius: 4, background: '#21262d', color: color || '#8b949e', whiteSpace: 'nowrap' }}>{children}</span>;
}

// ─── PARTNER PANEL ──────────────────────────────────────────────────────────
function PartnerPanel({ signups, onClose }) {
  const { PARTNER_GROUPS } = window.NDEC;

  const pgStats = PARTNER_GROUPS.map(pg => {
    const members = signups.filter(s => s.partnerGroup?.id === pg.id);
    const withInternet  = members.filter(s => s.onboarding.q2_internet_home).length;
    const freeEligible  = members.filter(s => s.sponsorship?.eligibleFree).length;
    const active        = members.filter(s => s.isActive).length;
    const classCount    = members.reduce((a,s) => a + s.classesEnrolled.length, 0);
    const topGoals      = {};
    members.forEach(s => { topGoals[s.onboarding.main_goal] = (topGoals[s.onboarding.main_goal]||0)+1; });
    const topGoal = Object.entries(topGoals).sort((a,b)=>b[1]-a[1])[0]?.[0] || '—';
    return { pg, count: members.length, withInternet, freeEligible, active, classCount, topGoal };
  });

  const total = pgStats.reduce((a,s) => a + s.count, 0) || 1;

  return (
    <div style={{margin:'12px 24px 0',background:'#161b22',border:'1px solid #a78bfa40',borderRadius:8,overflow:'hidden',animation:'slideDown 0.2s ease'}}>
      <div style={{padding:'12px 18px',borderBottom:'1px solid #30363d',display:'flex',justifyContent:'space-between',alignItems:'center'}}>
        <div style={{fontSize:13,fontWeight:600,color:'#e6edf3'}}>Partner Group Breakdown</div>
        <button onClick={onClose} style={{background:'none',border:'none',color:'#8b949e',cursor:'pointer',fontSize:16,lineHeight:1}}>✕</button>
      </div>
      <div style={{overflowX:'auto'}}>
        <table style={{width:'100%',borderCollapse:'collapse'}}>
          <thead>
            <tr>
              {['Partner Group','Enrollments','Share','Active','Home Internet','Free Eligible','Classes Enrolled','Top Goal'].map(h=>(
                <th key={h} style={{padding:'9px 16px',fontSize:11,color:'#8b949e',textAlign:'left',fontWeight:600,textTransform:'uppercase',letterSpacing:0.5,borderBottom:'1px solid #30363d',whiteSpace:'nowrap'}}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {pgStats.map(({pg,count,withInternet,freeEligible,active,classCount,topGoal})=>(
              <tr key={pg.id}
                onMouseEnter={e=>e.currentTarget.style.background='#1c2128'}
                onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                <td style={{padding:'10px 16px',borderBottom:'1px solid #21262d'}}>
                  <div style={{display:'flex',alignItems:'center',gap:8}}>
                    <span style={{width:10,height:10,borderRadius:'50%',background:pg.color,display:'inline-block',flexShrink:0}}/>
                    <span style={{fontSize:13,fontWeight:600,color:'#e6edf3'}}>{pg.name}</span>
                  </div>
                </td>
                <td style={{padding:'10px 16px',borderBottom:'1px solid #21262d'}}>
                  <span style={{fontSize:18,fontWeight:700,color:pg.color}}>{count}</span>
                </td>
                <td style={{padding:'10px 16px',borderBottom:'1px solid #21262d',minWidth:120}}>
                  <div style={{display:'flex',alignItems:'center',gap:8}}>
                    <div style={{flex:1,height:6,background:'#21262d',borderRadius:3}}>
                      <div style={{width:`${(count/total)*100}%`,height:'100%',background:pg.color,borderRadius:3}}/>
                    </div>
                    <span style={{fontSize:11,color:'#8b949e',flexShrink:0}}>{((count/total)*100).toFixed(1)}%</span>
                  </div>
                </td>
                <td style={{padding:'10px 16px',borderBottom:'1px solid #21262d'}}>
                  <span style={{fontSize:12,color:'#3fb950'}}>{active}</span>
                  <span style={{fontSize:11,color:'#484f58'}}> / {count}</span>
                </td>
                <td style={{padding:'10px 16px',borderBottom:'1px solid #21262d'}}>
                  <span style={{fontSize:12,color:'#58a6ff'}}>{withInternet}</span>
                  <span style={{fontSize:11,color:'#484f58'}}> ({count>0?Math.round(withInternet/count*100):0}%)</span>
                </td>
                <td style={{padding:'10px 16px',borderBottom:'1px solid #21262d'}}>
                  <span style={{fontSize:12,color:'#34d399'}}>{freeEligible}</span>
                  <span style={{fontSize:11,color:'#484f58'}}> ({count>0?Math.round(freeEligible/count*100):0}%)</span>
                </td>
                <td style={{padding:'10px 16px',borderBottom:'1px solid #21262d'}}>
                  <span style={{fontSize:12,color:'#e6edf3'}}>{classCount}</span>
                  <span style={{fontSize:11,color:'#484f58'}}> ({count>0?(classCount/count).toFixed(1):0} avg)</span>
                </td>
                <td style={{padding:'10px 16px',borderBottom:'1px solid #21262d'}}>
                  <span style={{fontSize:11,color:'#8b949e'}}>{topGoal}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ─── MAIN APP ────────────────────────────────────────────────────────────────
function App() {
  const { generateSignups, makeNewSignup } = window.NDEC;
  const [signups, setSignups] = useState(() => generateSignups(148));
  const [selected, setSelected] = useState(null);
  const timerRef = useRef(null);

  useEffect(() => {
    // 1–2 signups per minute: random interval between 30s and 60s
    function scheduleNext() {
      const delay = 30000 + Math.random() * 30000;
      return setTimeout(() => {
        setSignups((prev) => [makeNewSignup(prev.length), ...prev]);
        timerRef.current = scheduleNext();
      }, delay);
    }
    timerRef.current = scheduleNext();
    return () => clearTimeout(timerRef.current);
  }, []);

  const [classPanel, setClassPanel]     = useState(false);
  const [partnerPanel, setPartnerPanel] = useState(false);

  const totalEnrollments = signups.length;
  const totalClassEnrollments = signups.reduce((a, s) => a + s.classesEnrolled.length, 0);
  const partnerEnrollments = signups.filter((s) => s.partnerGroup).length;
  const activeThisWeek = signups.filter((s) => Date.now() - s.last_login < 7 * 86400000).length;

  return (
    <div style={{ minHeight: '100vh', background: '#0d1117', color: '#e6edf3', fontFamily: "'Helvetica Neue',Helvetica,Arial,sans-serif", display: 'flex', flexDirection: 'column' }}>
      <style>{`
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:0.35}}
        @keyframes ripple{0%{r:12;opacity:0.7}100%{r:22;opacity:0}}
        @keyframes slideDown{from{opacity:0;transform:translateY(-8px)}to{opacity:1;transform:translateY(0)}}
        *{box-sizing:border-box}
        ::-webkit-scrollbar{width:5px;height:5px}
        ::-webkit-scrollbar-track{background:#161b22}
        ::-webkit-scrollbar-thumb{background:#30363d;border-radius:3px}
      `}</style>

      {/* Header */}
      <header style={{ background: '#161b22', borderBottom: '1px solid #30363d', padding: '0 24px', display: 'flex', alignItems: 'center', height: 54, gap: 14, flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 30, height: 30, borderRadius: 6, background: 'linear-gradient(135deg,#3b82f6,#22d3ee)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, fontWeight: 900, color: '#fff' }}>N</div>
          <div>
            <div style={{ fontSize: 14, fontWeight: 700, color: '#e6edf3', lineHeight: 1 }}>NDEC</div>
            <div style={{ fontSize: 10, color: '#8b949e', lineHeight: 1, marginTop: 2 }}>Digital Literacy Portal</div>
          </div>
        </div>
        <div style={{ width: 1, height: 26, background: '#30363d' }} />
        <div style={{ fontSize: 13, color: '#8b949e' }}>Enrollment Dashboard</div>
        <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ width: 7, height: 7, borderRadius: '50%', background: '#3fb950', display: 'inline-block', animation: 'pulse 1.4s ease infinite' }} />
          <span style={{ fontSize: 12, color: '#8b949e' }}>Live · {timeAgo(new Date())}</span>
        </div>
      </header>

      {/* KPIs */}
      <div style={{ padding: '14px 24px 0', display: 'flex', gap: 12, flexShrink: 0 }}>
        <KPICard label="Total Enrollments" value={totalEnrollments} color="#58a6ff" live sub={`+${signups.filter((s) => s.isNew).length} new today`} />
        <KPICard label="Class Enrollments" value={totalClassEnrollments} color="#22d3ee" sub={classPanel ? '▲ Hide breakdown' : '▼ View breakdown'} onClick={() => setClassPanel((p) => !p)} clickable />
        <KPICard label="Partner Group Enrollments" value={partnerEnrollments} color="#a78bfa" sub={partnerPanel ? '▲ Hide breakdown' : '▼ View breakdown'} onClick={()=>setPartnerPanel(p=>!p)} clickable />
        <KPICard label="Active This Week" value={activeThisWeek} color="#3fb950" sub="signed in last 7 days" />
      </div>

      {/* Class enrollment panel */}
      {classPanel &&
      <div style={{ margin: '12px 24px 0', background: '#161b22', border: '1px solid #22d3ee40', borderRadius: 8, overflow: 'hidden', animation: 'slideDown 0.2s ease' }}>
          <div style={{ padding: '12px 18px', borderBottom: '1px solid #30363d', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: '#e6edf3' }}>Class Enrollment Overview</div>
            <button onClick={() => setClassPanel(false)} style={{ background: 'none', border: 'none', color: '#8b949e', cursor: 'pointer', fontSize: 16, lineHeight: 1 }}>✕</button>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 0 }}>
            <div style={{ padding: '16px 20px', borderRight: '1px solid #30363d' }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: '#8b949e', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 12 }}>Enrolled by Class</div>
              <EnrollmentBars signups={signups} mode="enrolled" />
            </div>
            <div style={{ padding: '16px 20px' }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: '#8b949e', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 12 }}>Recommended by Class</div>
              <EnrollmentBars signups={signups} mode="recommended" />
            </div>
          </div>
        </div>
      }

      {/* Partner group panel */}
      {partnerPanel && <PartnerPanel signups={signups} onClose={()=>setPartnerPanel(false)}/>}

      {/* Main grid */}
      <div style={{ display: 'flex', gap: 0, padding: '14px 24px', overflow: 'hidden', height: 'calc(100vh - 190px)' }}>
        {/* Map */}
        <div style={{ flex: '0 0 370px', background: '#161b22', border: '1px solid #30363d', borderRadius: 8, overflow: 'hidden', position: 'relative', display: 'flex', flexDirection: 'column' }}>
          <div style={{ padding: '10px 14px', borderBottom: '1px solid #30363d', flexShrink: 0, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: '#e6edf3' }}>Maine Enrollment Map</div>
            <div style={{ fontSize: 11, color: '#8b949e' }}>{signups.length} records</div>
          </div>
          <div style={{ flex: 1, position: 'relative', overflow: 'hidden' }}>
            <MaineMap signups={signups} onNodeClick={setSelected} selectedId={selected?.id} />
            {selected && <DetailPanel signup={selected} onClose={() => setSelected(null)} />}
          </div>
        </div>

        {/* Live feed — expanded */}
        <div style={{ flex: 1, marginLeft: 12 }}>
          <LiveFeed recentSignups={[...signups].sort((a, b) => a.user_registered - b.user_registered).slice(-50).reverse()} />
        </div>
      </div>

      {/* Table */}
      <div style={{ padding: '0 24px 24px', flexShrink: 0 }}>
        <SignupTable signups={signups} />
      </div>
    </div>);

}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);